from tkinter import*
from PIL import Image ,ImageTk #pip install pillow
import os
import subprocess


class custreportClass:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1100x500+220+130")

        self.root.title("Furniture Shop Management System ")
        self.root.config(bg="white")


        #===title===
        
        title=Label(self.root,text="Furniture Shop Management System",compound=LEFT,font=("times new roman",40,"bold"),bg="#010c48",fg="white",anchor="w",padx=20).place(x=0,y=0,relwidth=1,height=70) 
        
        leftMenu=Frame(self.root,bd=2,relief=RIDGE,bg="white")
        leftMenu.place(x=0,y=70,relwidth=1,height=40)
        btn_menu=Label(leftMenu,text="Customer Report",font=("times new roman",20),bg="light blue").pack(side=TOP,fill=X)


        self.lbl_item=Button(self.root,text="Report",bd=5,relief=RIDGE,bg="orange",fg="white",font=("goudy old style",20,"bold"),command=self.open_report)
        self.lbl_item.place(x=500,y=300)

    def open_report(self):
        report_path =("C:/Furniture shop/reportC.pdf")# Specify the path to the report
        #r"‪‪C:\Furniture shop\reportC.pdf"
        #im1=Image.open("images/img2.jpg")

        # Check if the file exists
        if os.path.exists(report_path):
            # Open the PDF file using the default PDF viewer
            subprocess.Popen([report_path], shell=True)
        else:
            print("Report not found.")
            # You can add a message box here if you want to show an error (optional)
            messagebox.showerror("Error", "Report file not found!")   


   

    #def report(self):
       # self.new_win=Toplevel(self.root)
      #  self.new_obj=reportClass(self.new_win)
       
if __name__=="__main__":
    root=Tk()
    obj=custreportClass(root)
    root.mainloop()

