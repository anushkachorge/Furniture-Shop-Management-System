from tkinter import*
from PIL import Image,ImageTk #pip install pillow
from tkinter import  ttk,messagebox
import sqlite3
class stockClass:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1100x500+220+130")
        self.root.title("Furniture Shop Management system ")
        self.root.config(bg="white")
        self.root.focus_force()
        #===========================
        self.var_pid=StringVar()
        self.var_cat=StringVar()
        self.cat_list=[]
        self.fetch_cat_sup()

        self.var_name=StringVar()
        self.var_price=StringVar()
        self.var_qty=StringVar()
        self.var_status=StringVar()
        self.var_searchby=StringVar()
        self.var_searchtxt=StringVar()

        product_Frame=Frame(self.root,bd=2,relief=RIDGE,bg="white")
        product_Frame.place(x=30,y=100,width=1000,height=275)

        #====title===
        title=Label(product_Frame,text="Manage Stock Details",font=("goudy old style",18),bg="#0f4d7d",fg="white",cursor="hand2").pack(side=TOP,fill=X)

        #====column1
        lbl_category=Label(product_Frame,text="Category",font=("goudy old style",18),bg="white").place(x=40,y=50)
        lbl_name=Label(product_Frame,text="Name",font=("goudy old style",18),bg="white").place(x=40,y=85)
        lbl_price=Label(product_Frame,text="Price",font=("goudy old style",18),bg="white").place(x=40,y=125)
        lbl_qty=Label(product_Frame,text="Quantity",font=("goudy old style",18),bg="white").place(x=40,y=155)
        lbl_status=Label(product_Frame,text="Status",font=("goudy old style",18),bg="white").place(x=40,y=185)
        
        
        #====column2
        cmb_cat=ttk.Combobox(product_Frame,textvariable=self.var_cat,values=self.cat_list,state='readonly',justify=CENTER,font=("goudy old style",15))
        cmb_cat.place(x=200,y=50,width=200)
        cmb_cat.current(0)

        

        txt_name=Entry(product_Frame,textvariable=self.var_name,font=("goudy old style",15),bg='lightyellow').place(x=200,y=95,width=200)
        txt_price=Entry(product_Frame,textvariable=self.var_price,font=("goudy old style",15),bg='lightyellow').place(x=200,y=135,width=200)
        txt_qty=Entry(product_Frame,textvariable=self.var_qty,font=("goudy old style",15),bg='lightyellow').place(x=200,y=165,width=200)
        
        cmb_status=ttk.Combobox(product_Frame,textvariable=self.var_status,values=("Active","Inactive"),state='readonly',justify=CENTER,font=("goudy old style",15))
        cmb_status.place(x=200,y=195,width=200)
        cmb_status.current(0)

        #===Buttons===
        search_save=Button(product_Frame,text="Save ",command=self.add,font=("goudy old style",15),bg="#2196f3",fg="white",cursor="hand2").place(x=450,y=200,width=100,height=40)
        search_update=Button(product_Frame,text="Update",command=self.update,font=("goudy old style",15),bg="#4caf50",fg="white",cursor="hand2").place(x=600,y=200,width=100,height=40)
        search_delete=Button(product_Frame,text="Delete",command=self.delete,font=("goudy old style",15),bg="#f44336",fg="white",cursor="hand2").place(x=750,y=200,width=100,height=40)
        search_clear=Button(product_Frame,text="Clear",command=self.clear,font=("goudy old style",15),bg="#607d8b",fg="white",cursor="hand2").place(x=880,y=200,width=100,height=40)

        #=====searchframe====
        searchframe=LabelFrame(self.root,text="Search Customer",font=("goudy old style",12,"bold"),bg="white")
        searchframe.place(x=250,y=20,width=600,height=70)

        #====options===
        cmb_search=ttk.Combobox(searchframe,textvariable=self.var_searchby,values=("Select","Category","Name"),state='readonly',justify=CENTER,font=("imes new roman",15))
        cmb_search.place(x=10,y=10,width=180)
        cmb_search.current(0)

        txt_search=Entry(searchframe,textvariable=self.var_searchtxt,font=("goudy old style",15),bg="lightyellow").place(x=200,y=10)
        search_btn=Button(searchframe,text="Search",command=self.search,font=("goudy old style",15),bg="#4caf50",fg="white",cursor="hand2").place(x=410,y=9,width=150,height=30)


        #===Product Details===
        p_frame=Frame(self.root,bd=3,relief=RIDGE)
        p_frame.place(x=20,y=380,width=1100,height=300)

        scrolly=Scrollbar(p_frame,orient=VERTICAL) 
        scrollx=Scrollbar(p_frame,orient=HORIZONTAL) 

        self.ProductTable=ttk.Treeview(p_frame,columns=("pid","Category","name","price","qty","status"),yscrollcommand=scrolly.set,xscrollcommand=scrollx.set)
        scrollx.pack(side=BOTTOM,fill=X)
        scrolly.pack(side=RIGHT,fill=Y)
        scrollx.config(command=self.ProductTable.xview)
        scrolly.config(command=self.ProductTable.yview)


        self.ProductTable.heading("pid",text="P ID")
        self.ProductTable.heading("Category",text="Category")
        self.ProductTable.heading("name",text="Name")
        self.ProductTable.heading("price",text="Price")
        self.ProductTable.heading("qty",text="Quantity")
        self.ProductTable.heading("status",text="Status")
       
       
       
        self.ProductTable["show"]="headings"

        self.ProductTable.column("pid", width=90)
        self.ProductTable.column("Category",width=100)
        self.ProductTable.column("name",width=100)
        self.ProductTable.column("price",width=100)
        self.ProductTable.column("qty",width=100)
        self.ProductTable.column("status",width=100)
        
        self.ProductTable.pack(fill=BOTH,expand=1)
        self.ProductTable.bind("<ButtonRelease-1>",self.get_data)

        self.show()
       
    

#===============================================================
    def fetch_cat_sup(self):
        self.cat_list.append("Empty")
        con=sqlite3.connect(database=r'ims.db')
        cur=con.cursor()
        try:
            cur.execute("Select name from item_category")
            cat=cur.fetchall()
            if len(cat)>0:
                del self.cat_list[:]
                self.cat_list.append("Select")
                for i in cat:
                    self.cat_list.append(i[0])

        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
#=====================================
    def add(self):
        con=sqlite3.connect(database=r'ims.db')
        cur=con.cursor()
        try:
            if self.var_cat.get()=="Select" or self.var_cat.get()=="Empty" or  self.var_name.get()=="":
                messagebox.showerror("Error","All Fields are Must be required",parent =self.root)
            else:
                 cur.execute("Select * from product where name=?",(self.var_name.get(),))
                 row=cur.fetchone()
                 if row != None:
                     messagebox.showerror("Error","this product already present ,try diffrent",parent=self.root)
                 else:
                     cur.execute("Insert into product (Category,name,price,qty,status) values(?,?,?,?,?)",(
                                              self.var_cat.get(),
                                              self.var_name.get(),
                                              self.var_price.get(),
                                              self.var_qty.get(),
                                              self.var_status.get(),
                                              

                     ))
                     con.commit()
                     messagebox.showinfo("Success","Product Added Successfully",parent=self.root)
                     self.show()
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)


    def show(self):
        con=sqlite3.connect(database=r'ims.db')
        cur=con.cursor()
        try:
            cur.execute("Select * from product")
            rows=cur.fetchall()
            self.ProductTable.delete(*self.ProductTable.get_children())
            for row in rows:
                self.ProductTable.insert('',END,values=row)
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)

    def get_data(self,ev):
        f=self.ProductTable.focus()
        content=(self.ProductTable.item(f))
        row=content['values']
        self.var_pid.set(row[0])
        self.var_cat.set(row[1])
        self.var_name.set(row[2])
        self.var_price.set(row[3])
        self.var_qty.set(row[4])
        self.var_status.set(row[5])
                                              
        

    #====
    def update(self):
        con=sqlite3.connect(database=r'ims.db')
        cur=con.cursor()
        try:
            if self.var_pid.get()=="":
                messagebox.showerror("Error","Please select product from list",parent =self.root)
            else:
                 cur.execute("Select * from product where pid=?",(self.var_pid.get(),))
                 row=cur.fetchone()
                 if row == None:
                     messagebox.showerror("Error","Invalid Product ID",parent=self.root)
                 else:
                     cur.execute("Update  product set category=?,name=?,price=?,qty=?,status=? where pid=?",(
                                              self.var_cat.get(),
                                              self.var_name.get(),
                                              self.var_price.get(),
                                              self.var_qty.get(),
                                              self.var_status.get(),
                                              self.var_pid.get()

                     ))
                     con.commit()
                     messagebox.showinfo("Success","Product updated Successfully",parent=self.root)
                     self.show()
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)

    def delete(self):
        con=sqlite3.connect(database=r'ims.db')
        cur=con.cursor()
        try:
            if self.var_pid.get()=="":
                messagebox.showerror("Error","select product from the list",parent =self.root)
            else:
                 cur.execute("Select * from product where pid=?",(self.var_pid.get(),))
                 row=cur.fetchone()
                 if row == None:
                     messagebox.showerror("Error","Invalid Product",parent=self.root)
                 else:
                    op=messagebox.askyesno("Confim","Do you really want to delete?",parent=self.root)
                    if op==True:
                        cur.execute("delete from product where pid=?",(self.var_pid.get(),))
                        con.commit()
                        messagebox.showinfo("Delete","Product Deleted Successfully",parent=self.root)
                        self.clear()

        except:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)




    def clear(self):
        self.var_cat.set("Select")
        self.var_name.set("")
        self.var_price.set("")
        self.var_qty.set("")
        self.var_status.set("Active")
        self.var_pid.set("")
        self.var_searchtxt.set("")
        self.var_searchby.set("Select")
        self.show()

    def search(self):
        con=sqlite3.connect(database=r'ims.db')
        cur=con.cursor()
        try:
            if self.var_searchby.get()=="Select":
                messagebox.showerror("Error","Select Search By option",parent=self.root)
            elif self.var_searchtxt.get()=="":
                messagebox.showerror("Error","Search input should be requied",parent=self.root)
            else:    
                cur.execute("Select * from product  where "+self.var_searchby.get()+" LIKE '%"+self.var_searchtxt.get()+"'%")
                rows=cur.fetchall()
                if len(rows)!=0:
                    self.ProductTable.delete(*self.ProductTable.get_children())
                    for row in rows:
                        self.ProductTable.insert('',END,values=row)
                else:
                    messagebox.showerror("Error","No record Found",parent=self.root)

        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)





if __name__=="__main__":
    root=Tk()
    obj=stockClass(root)
    root.mainloop()
