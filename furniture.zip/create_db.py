+import sqlite3
def create_db():
    con=sqlite3.connect(database=r'ims.db')
    cur=con.cursor()

    cur.execute('''CREATE TABLE IF NOT EXISTS users( username TEXT NOT NULL,password TEXT NOT NULL)''')
    con.commit()
    
    cur.execute("CREATE TABLE IF NOT EXISTS customer(Cust_id INTEGER PRIMARY KEY AUTOINCREMENT,Gender text,Contact text,Name text,Address text,Date text)")
    con.commit()

    cur.execute("CREATE TABLE IF NOT EXISTS item_category(cat_id INTEGER PRIMARY KEY AUTOINCREMENT,Name text)")
    con.commit()

    cur.execute("CREATE TABLE IF NOT EXISTS stock(Stock_id INTEGER PRIMARY KEY AUTOINCREMENT,Stockname text,qty text)")
    con.commit()

    cur.execute("CREATE TABLE IF NOT EXISTS billing(Pid INTEGER PRIMARY KEY AUTOINCREMENT,Name text,Price text,QTY text,Status text)")
    con.commit()

    cur.execute("CREATE TABLE IF NOT EXISTS product(pid INTEGER PRIMARY KEY AUTOINCREMENT,Category text,name text,price text,qty text,status text)")
    con.commit()

    cur.execute("CREATE TABLE IF NOT EXISTS supplier(invoice INTEGER PRIMARY KEY AUTOINCREMENT,name text,contact text,desc text)")
    con.commit()

    #cur.execute("CREATE TABLE IF NOT EXISTS sbilling(invoice INTEGER PRIMARY KEY AUTOINCREMENT,name text,contact text,desc text)")
    #con.commit()





create_db()
