from tkinter import*
from PIL import Image,ImageTk #pip install pillow
from tkinter import ttk,messagebox

class sbillClass:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1350x700+0+0")
        self.root.title("Furniture Shop Management System")
        self.root.config(bg="white")


        #===title===
        #self.icon_title=PhotoImage(file="imges/logo1.png")
        title=Label(self.root,text="Furniture Shop Management System",compound=LEFT,font=("times new roman",40,"bold"),bg="#010c48",fg="white",anchor="w",padx=20).place(x=0,y=0,relwidth=1,height=70)
        #image=self.icon_title,
        #==button logout==
        btn_logout=Button(self.root,text="Logout",font=("times new roman",15,"bold"),bg="yellow",cursor="hand2").place(x=1150,y=10,height=50,width=150)

        #==clock===
        self.lb1_clock=Label(self.root,text="Welcome to Furniture Shop Management System\t\t Date: DD-MM-YYYY\t\t Time: HH:MM:SS",font=("times new roman",15),bg="#4d636d",fg="white")
        self.lb1_clock.place(x=0,y=70,relwidth=1,height=30)


        #====product_Frame=====
        self.var_search=StringVar()

        
        productFrame1=Frame(self.root,bd=4,relief=RIDGE,bg="white")
        productFrame1.place(x=6,y=110,width=410,height=500)

        pTitle=Label(productFrame1,text="All products",font=("goudy old style",20,"bold"),bg="#262626",fg="white").pack(side=TOP,fill=X)

        #===Product Search Frame=====
        productFrame2=Frame(productFrame1,bd=2,relief=RIDGE,bg="white")
        productFrame2.place(x=2,y=42,width=398,height=90)

        lbl_search=Label(productFrame2,text="search  product  | By Name",font=("times new roman",15,"bold"),bg="white",fg="green").place(x=2,y=5)

        
        lbl_search=Label(productFrame2,text="Product Name",font=("times new roman",15,"bold"),bg="white").place(x=2,y=45)
        txt_search=Entry(productFrame2,textvariable=self.var_search,font=("times new roman",15),bg="lightyellow").place(x=128,y=47,width=150,height=22)
        btn_search=Button(productFrame2,text="Search",font=("goudy old style",15),bg="#2196f3",fg="white",cursor="hand2").place(x=285,y=45,width=100,height=25)
        btn_show_all=Button(productFrame2,text="Show all",font=("goudy old style",15),bg="#083531",fg="white",cursor="hand2").place(x=285,y=10,width=100,height=25)
        
        #===Product Detail Frame=====
        productFrame3=Frame(productFrame1,bd=3,relief=RIDGE)
        productFrame3.place(x=2,y=140,width=398,height=320)

        scrolly=Scrollbar(productFrame3,orient=VERTICAL) 
        scrollx=Scrollbar(productFrame3,orient=HORIZONTAL) 

        self.product_Details=ttk.Treeview(productFrame3,columns=("pid","name","price","qty","status"),yscrollcommand=scrolly.set,xscrollcommand=scrollx.set)
        scrollx.pack(side=BOTTOM,fill=X)
        scrolly.pack(side=RIGHT,fill=Y)
        scrollx.config(command=self.product_Details.xview)
        scrolly.config(command=self.product_Details.yview)


        self.product_Details.heading("pid",text="P ID")
        self.product_Details.heading("name",text="Name")
        self.product_Details.heading("price",text="Price")
        self.product_Details.heading("qty",text="QTY")   
        self.product_Details.heading("status",text="Status")   
        self.product_Details["show"]="headings"

        self.product_Details.column("pid", width=90)
        self.product_Details.column("name",width=100)
        self.product_Details.column("price",width=100)
        self.product_Details.column("qty",width=100)
        self.product_Details.column("status",width=100)
        self.product_Details.pack(fill=BOTH,expand=1)
        # self.product_Details.bind("<ButtonRelease-1>",self.get_data)
        lbl_name=Label(productFrame1,text="Note:'Enter 0 Quantity to remove product from the Cart'",font=("goudy old style",12),anchor='w',bg="white",fg="red").pack(side=BOTTOM,fill=X)
        
        #====CustomerFrame======
        self.var_name=StringVar()
        self.var_contact=StringVar()
        customerFrame=Frame(self.root,bd=4,relief=RIDGE,bg="white")
        customerFrame.place(x=420,y=110,width=530,height=70)

        cTitle=Label(customerFrame,text="Product Detalis",font=("goudy old style",15),bg="lightgray").pack(side=TOP,fill=X)
        lbl_name=Label(customerFrame,text="Name",font=("times new roman",15),bg="white").place(x=5,y=35)
        txt_search=Entry(customerFrame,textvariable=self.var_name,font=("times new roman",13),bg="lightyellow").place(x=80,y=35,width=180)

        lbl_contact=Label(customerFrame,text="Contact No.",font=("times new roman",15),bg="white").place(x=270,y=35)
        txt_search=Entry(customerFrame,textvariable=self.var_contact,font=("times new roman",13),bg="lightyellow").place(x=380,y=35,width=140)

        #=======Cal Frame=======
        Cal_Cart_Frame=Frame(self.root,bd=2,relief=RIDGE,bg="white")
        Cal_Cart_Frame.place(x=420,y=190,width=530,height=360)

        #=======Calculator Frame=======
        self.var_cal_input=StringVar()
        Cal_Frame=Frame(Cal_Cart_Frame,bd=2,relief=RIDGE,bg="white")
        Cal_Frame.place(x=5,y=10,width=268,height=340)

        self.txt_cal_input=Entry(Cal_Frame,textvariable=self.var_cal_input,font=('arial',15,'bold'),width=21,bd=10,relief=GROOVE)
        self.txt_cal_input.grid(row=0,columnspan=4)

        #=======Cart Frame=======
        cartFrame=Frame(Cal_Cart_Frame,bd=3,relief=RIDGE)
        cartFrame.place(x=280,y=8,width=245,height=342)
        cartTitle=Label(cartFrame,text="Cart \t Total Product:[0]",font=("goudy old style",15),bg="lightgray").pack(side=TOP,fill=X)

        scrolly=Scrollbar(cartFrame,orient=VERTICAL) 
        scrollx=Scrollbar(cartFrame,orient=HORIZONTAL) 

        self.CartTable=ttk.Treeview(cartFrame,columns=("pid","name","price","qty","status"),yscrollcommand=scrolly.set,xscrollcommand=scrollx.set)
        scrollx.pack(side=BOTTOM,fill=X)
        scrolly.pack(side=RIGHT,fill=Y)
        scrollx.config(command=self.CartTable.xview)
        scrolly.config(command=self.CartTable.yview)


        self.CartTable.heading("pid",text="P ID")
        self.CartTable.heading("name",text="Name")
        self.CartTable.heading("price",text="Price")
        self.CartTable.heading("qty",text="QTY")   
        self.CartTable.heading("status",text="Status")   
        self.CartTable["show"]="headings"

        self.CartTable.column("pid", width=40)
        self.CartTable.column("name",width=100)
        self.CartTable.column("price",width=90)
        self.CartTable.column("qty",width=40)
        self.CartTable.column("status",width=90)
        self.CartTable.pack(fill=BOTH,expand=1)
        # self.CartTable.bind("<ButtonRelease-1>",self.get_data)
        
        #=======ADD CART widgets Frame=======
        self.var_pid=StringVar()
        self.var_pname=StringVar()
        self.var_price=StringVar()
        self.var_qty=StringVar()
        self.var_stock=StringVar()

        Add_CartwidgetsFrame=Frame(self.root,bd=2,relief=RIDGE,bg="white")
        Add_CartwidgetsFrame.place(x=420,y=550,width=530,height=85)

        lbl_p_name=Label(Add_CartwidgetsFrame,text="Product Name",font=("times new roman",15),bg="white").place(x=5,y=5)
        txt_p_name=Entry(Add_CartwidgetsFrame,textvariable=self.var_pname,font=("times new roman",15),bg="lightyellow",state='readonly').place(x=5,y=30,width=190,height=22)

        lbl_p_price=Label(Add_CartwidgetsFrame,text="Price Par Qty",font=("times new roman",15),bg="white").place(x=230,y=5)
        txt_p_price=Entry(Add_CartwidgetsFrame,textvariable=self.var_pname,font=("times new roman",15),bg="lightyellow",state='readonly').place(x=230,y=30,width=150,height=22)

        lbl_p_qty=Label(Add_CartwidgetsFrame,text=" Quantity",font=("times new roman",15),bg="white").place(x=390,y=5)
        txt_p_qty=Entry(Add_CartwidgetsFrame,textvariable=self.var_pname,font=("times new roman",15),bg="lightyellow",state='readonly').place(x=390,y=30,width=100,height=22)

        self.lbl_instock=Label(Add_CartwidgetsFrame,text="In Stock [99999]",font=("times new roman",12),bg="white")
        self.lbl_instock.place(x=5,y=50)

        btn_clear=Button(Add_CartwidgetsFrame,text="clear",font=("times new roman",12,"bold"),bg="lightgray",cursor="hand2").place(x=190,y=60,width=100,height=20)
        btn_add_card=Button(Add_CartwidgetsFrame,text="Add | update",font=("times new roman",12,"bold"),bg="orange",cursor="hand2").place(x=340,y=60,width=100,height=20)
        
        


if __name__=="__main__":
    root=Tk()
    obj=sbillClass(root)
    root.mainloop()
