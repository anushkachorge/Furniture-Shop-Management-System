from tkinter import*
from PIL import Image,ImageTk #pip install pillow
from tkinter import  ttk,messagebox
import sqlite3
class SupplierClass:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1100x500+220+130")
        self.root.title("Furniture Shop Management system ")
        self.root.config(bg="white")
        self.root.focus_force()
        #===========================
        #====All Variables
        self.var_searchby=StringVar()
        self.var_searchtxt=StringVar()



        self.var_Sup_id=StringVar()
        self.var_name=StringVar()
        self.var_Contact=StringVar()
        


        #=====self.root====
        #====options========
        lbl_search=Label(self.root,text="Invoice No.",bg="white",font=("Times new roman",15))
        lbl_search.place(x=700,y=80)
        

        txt_search=Entry(self.root,textvariable=self.var_searchtxt,font=("goudy old style",15),bg="lightyellow").place(x=800,y=80,width=160)
        search_btn=Button(self.root,text="Search",command=self.search,font=("goudy old style",15),bg="#4caf50",fg="white",cursor="hand2").place(x=980,y=79,width=100,height=28)

        #====title===
        title=Label(self.root,text="Supplier Details",font=("goudy old style",20,"bold"),bg="#0f4d7d",fg="white",cursor="hand2").place(x=50,y=10,width=1000,height=40)

        #===content==
        #==row1===
        lbl_supplier_invoice=Label(self.root,text="Supplier Id.",font=("goudy old style",15),bg="white").place(x=50,y=80)
        txt_supplier_invoice=Entry(self.root,textvariable=self.var_Sup_id,font=("goudy old style",15),bg="lightyellow").place(x=180,y=80,width=180)
        
        
        #===row2==
        lbl_name=Label(self.root,text="Name",font=("goudy old style",15),bg="white").place(x=50,y=120)
        txt_name=Entry(self.root,textvariable=self.var_name,font=("goudy old style",15),bg="lightyellow").place(x=180,y=120,width=180)
        
        #===row3==
        lbl_Contact=Label(self.root,text="Contact",font=("goudy old style",15),bg="white").place(x=50,y=160)
        txt_Contact=Entry(self.root,textvariable=self.var_Contact,font=("goudy old style",15),bg="lightyellow").place(x=180,y=160,width=180)
        

        #===row4==
        lbl_desc=Label(self.root,text="Description",font=("goudy old style",15),bg="white").place(x=50,y=200)
        self.txt_desc=Text(self.root,font=("goudy old style",15),bg="lightyellow")
        self.txt_desc.place(x=180,y=200,width=470,height=120)
        
        #===Buttons===
        search_save=Button(self.root,text="Save ",command=self.add,font=("goudy old style",15),bg="#2196f3",fg="white",cursor="hand2").place(x=180,y=370,width=110,height=35)
        search_update=Button(self.root,text="Update",command=self.update,font=("goudy old style",15),bg="#4caf50",fg="white",cursor="hand2").place(x=300,y=370,width=110,height=35)
        search_delete=Button(self.root,text="Delete",command=self.delete,font=("goudy old style",15),bg="#f44336",fg="white",cursor="hand2").place(x=420,y=370,width=110,height=35)
        search_clear=Button(self.root,text="Clear",command=self.clear,font=("goudy old style",15),bg="#607d8b",fg="white",cursor="hand2").place(x=540,y=370,width=110,height=35)

       #===Paitent Details===
        pait_frame=Frame(self.root,bd=3,relief=RIDGE)
        pait_frame.place(x=700,y=120,width=400,height=350)

        scrolly=Scrollbar(pait_frame,orient=VERTICAL) 
        scrollx=Scrollbar(pait_frame,orient=HORIZONTAL) 

        self.SupplierTable=ttk.Treeview(pait_frame,columns=("Sup_id","name","contact","desc"),yscrollcommand=scrolly.set,xscrollcommand=scrollx.set)
        scrollx.pack(side=BOTTOM,fill=X)
        scrolly.pack(side=RIGHT,fill=Y)
        scrollx.config(command=self.SupplierTable.xview)
        scrolly.config(command=self.SupplierTable.yview)


        self.SupplierTable.heading("Sup_id",text="Sup ID")
        self.SupplierTable.heading("name",text="name")
        self.SupplierTable.heading("contact",text="contact")
        self.SupplierTable.heading("desc",text="Description")   
        self.SupplierTable["show"]="headings"

        self.SupplierTable.column("Sup_id", width=90)
        self.SupplierTable.column("name",width=100)
        self.SupplierTable.column("contact",width=100)
        self.SupplierTable.column("desc",width=100)
        self.SupplierTable.pack(fill=BOTH,expand=1)
        self.SupplierTable.bind("<ButtonRelease-1>",self.get_data)

        self.show()
    
#===============================================================
    def add(self):
        con=sqlite3.connect(database=r'ims.db')
        cur=con.cursor()
        try:
            if self.var_Sup_id.get()=="":
                messagebox.showerror("Error","Invoice Number Must be required",parent =self.root)
            else:
                 cur.execute("Select * from supplier where invoice=?",(self.var_Sup_id.get(),))
                 row=cur.fetchone()
                 if row != None:
                     messagebox.showerror("Error","this Supplier number already assigned ,try diffrent",parent=self.root)
                 else:
                     cur.execute("Insert into supplier (Sup_id,name,contact,desc) values(?,?,?,?)",(
                                              self.var_Sup_id.get(),
                                              self.var_name.get(),
                                              self.var_Contact.get(), 
                                              self.txt_desc.get('1.0',END),
                                              

                     ))
                     con.commit()
                     messagebox.showinfo("Success","supplier Added Successfully",parent=self.root)
                     self.show()
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)


    def show(self):
        con=sqlite3.connect(database=r'ims.db')
        cur=con.cursor()
        try:
            cur.execute("Select * from supplier")
            rows=cur.fetchall()
            self.SupplierTable.delete(*self.SupplierTable.get_children())
            for row in rows:
                self.SupplierTable.insert('',END,values=row)
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)

    def get_data(self,ev):
        f=self.SupplierTable.focus()
        content=(self.SupplierTable.item(f))
        row=content['values']
        #print(row)
        self.var_Sup_id.set(row[0])
        self.var_name.set(row[1])
        self.var_Contact.set(row[2])                                   
        self.txt_desc.delete('1.0',END)
        self.txt_desc.insert(END,row[3])
        

    #====
    def update(self):
        con=sqlite3.connect(database=r'ims.db')
        cur=con.cursor()
        try:
            if self.var_Sup_id.get()=="":
                messagebox.showerror("Error","Invoice number Must be required",parent =self.root)
            else:
                 cur.execute("Select * from supplier where Sup_id=?",(self.var_Sup_id.get(),))
                 row=cur.fetchone()
                 if row == None:
                     messagebox.showerror("Error","Invalid Supplier number",parent=self.root)
                 else:
                     cur.execute("Update  supplier set name=?,contact=?,desc=? where invoice=?",(
                                              self.var_name.get(),
                                              self.var_Contact.get(),            
                                              self.txt_desc.get('1.0',END),
                                              self.var_Sup_id.get(),

                     ))
                     con.commit()
                     messagebox.showinfo("Success","supplier updated Successfully",parent=self.root)
                     self.show()
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)

    def delete(self):
        con=sqlite3.connect(database=r'ims.db')
        cur=con.cursor()
        try:
            if self.var_Sup_id.get()=="":
                messagebox.showerror("Error","invoice number Must be required",parent =self.root)
            else:
                 cur.execute("Select * from supplier where Sup_id=?",(self.var_Sup_id.get(),))
                 row=cur.fetchone()
                 if row == None:
                     messagebox.showerror("Error","Invalid Supplier number",parent=self.root)
                 else:
                    op=messagebox.askyesno("Confim","Do you really want to delete?",parent=self.root)
                    if op==True:
                        cur.execute("delete from supplier where invoice=?",(self.var_Sup_id.get(),))
                        con.commit()
                        messagebox.showinfo("Delete","supplier Deleted Successfully",parent=self.root)
                        self.clear()

        except:
            messagebox.showerror("Error",f"Error due to : {str()}",parent=self.root)




    def clear(self):
        self.var_Sup_id.set("")
        self.var_name.set("")
        self.var_Contact.set("")                                    
        self.txt_desc.delete('1.0',END)
        self.var_searchtxt.set("")
        
        self.show()

    def search(self):
        con=sqlite3.connect(database=r'ims.db')
        cur=con.cursor()
        try:
            if self.var_searchtxt.get()=="":
                messagebox.showerror("Error","Supplier number should be requied",parent=self.root)
            else:    
                cur.execute("Select * from supplier where Sup-id=?",(self.var_searchtxt.get(),))
                row=cur.fetchone()
                if row!=None:
                    self.SupplierTable.delete(*self.SupplierTable.get_children())
                    self.SupplierTable.insert('',END,values=row)
                else:
                    messagebox.showerror("Error","No record Found",parent=self.root)

        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)

if __name__=="__main__":
    root=Tk()
    obj=SupplierClass(root)
    root.mainloop()
