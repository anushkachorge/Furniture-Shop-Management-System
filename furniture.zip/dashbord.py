from tkinter import*
from PIL import Image,ImageTk
from customer import CustomerClass
from item_category import categoryClass
from billing import billClass
from product import productClass
from stock import stockClass
from supplier import SupplierClass
from sbilling import sbillClass
from report import reportClass



#from customer import*
class IMS:
    def __init__(self,root):
        self.root=root
        
                ######All Images#######


        self.im1=Image.open("images/img1.png")
        self.im1=self.im1.resize((1350,700))
        self.im1=ImageTk.PhotoImage(self.im1)
        self.lbl_im1=Label(self.root,image=self.im1,bd=2,relief=RAISED)
        self.lbl_im1.place(x=0,y=0)

        ############ Frame Title##############

        title=Label(self.root,text="Furniture Shop Management System",font=("times new roman",40,"bold"),bg="#010c48",fg="white",anchor="w",padx=20).place(x=0,y=0,relwidth=1,height=70)
        self.root.title("Furniture shop management system")
        self.root.geometry("1350x700+0+0")
        self.root.title("Furniture Shop Management System")
        self.root.config(bg="white")






        ######All Images#######

        
        #im1=Image.open("images/img1.png")
        #im1=im1.resize((1350,700))
        #im1=ImageTk.PhotoImage(im1)
        #lbl_im1=Label(root,image=im1,bd=2,relief=RAISED)
        #lbl_im1.place(x=0,y=0)


        
        '''self.im1=Image.open("images/img1.png")
        self.im1=self.im1.resize((1350,700))
        self.im1=ImageTk.PhotoImage(self.im1)
        self.lbl_im1=Label(self.root,image=self.im1,bd=2,relief=RAISED)
        self.lbl_im1.place(x=0,y=0)'''




        #frame left sideF
        leftMenu=Frame(self.root,bd=2,relief=RIDGE,bg="white")
        leftMenu.place(x=0,y=70,relwidth=1,height=40)

        btn_menu=Label(leftMenu,text="Menu",font=("times new roman",20),bg="light blue").pack(side=TOP,fill=X)
        

        #content

        self.lbl_customer=Button(self.root,text="Customer",command=self.customer,bd=5,relief=RIDGE,bg="orange",fg="white",font=("goudy old style",20,"bold"))
        self.lbl_customer.place(x=70,y=180,height=150,width=250)

        self.lbl_item_category=Button(self.root,text="Item Category",command=self.item,bd=5,relief=RIDGE,bg="orange",fg="white",font=("goudy old style",20,"bold"))
        self.lbl_item_category.place(x=390,y=180,height=150,width=250)

        self.lbl_stock=Button(self.root,text="Stock",command=self.stock,bd=5,relief=RIDGE,bg="orange",fg="white",font=("goudy old style",20,"bold"))
        self.lbl_stock.place(x=710,y=180,height=150,width=250)

        self.lbl_item=Button(self.root,text="Product",command=self.product,bd=5,relief=RIDGE,bg="orange",fg="white",font=("goudy old style",20,"bold"))
        self.lbl_item.place(x=1030,y=180,height=150,width=250)

        self.lbl_bill=Button(self.root,text="Bill",command=self.bill,bd=5,relief=RIDGE,bg="orange",fg="white",font=("goudy old style",20,"bold"))
        self.lbl_bill.place(x=70,y=400,height=150,width=250)

        #self.lbl_item=Button(self.root,text="Product",command=self.product,bd=5,relief=RIDGE,bg="orange",fg="white",font=("goudy old style",20,"bold"))
        #self.lbl_item.place(x=500,y=400,height=150,width=300)

        self.lbl_Supplier=Button(self.root,text="Supplier",command=self.supplier,bd=5,relief=RIDGE,bg="orange",fg="white",font=("goudy old style",20,"bold"))
        self.lbl_Supplier.place(x=390,y=400,height=150,width=250)

        self.lbl_Supplier_Bill=Button(self.root,text="Supplier Bill",command=self.supplier_bill,bd=5,relief=RIDGE,bg="orange",fg="white",font=("goudy old style",20,"bold"))
        self.lbl_Supplier_Bill.place(x=710,y=400,height=150,width=250)
        
        self.lbl_Report=Button(self.root,text="Report",command=self.report,bd=5,relief=RIDGE,bg="orange",fg="white",font=("goudy old style",20,"bold"))
        self.lbl_Report.place(x=1030,y=400,height=150,width=250)




#=================================
    def customer(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=CustomerClass(self.new_win)

    def item(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=categoryClass(self.new_win)

    def stock(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=stockClass(self.new_win)

    def bill(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=billClass(self.new_win)
        
    def product(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=productClass(self.new_win)

    def supplier(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=SupplierClass(self.new_win)


    def supplier_bill(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=sbillClass(self.new_win)
        
    def report(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=reportClass(self.new_win)



if __name__=="__main__":
    root=Tk()
    obj=IMS(root)
    root.mainloop()
