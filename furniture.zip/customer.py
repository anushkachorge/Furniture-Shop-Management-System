
from tkinter import *
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime

class CustomerClass:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1100x500+220+130")
        self.root.title("Furniture Shop Management System")
        self.root.config(bg="white")
        self.root.focus_force()

        # Variables
        self.var_searchby = StringVar()
        self.var_searchtxt = StringVar()
        self.var_cust_id = StringVar()
        self.var_gender = StringVar()
        self.var_contact = StringVar()
        self.var_name = StringVar()
        self.var_address = StringVar()
        self.var_date = StringVar()

        # Search Frame
        search_frame = LabelFrame(self.root, text="Search Customer", font=("Goudy Old Style", 12, "bold"), bg="white")
        search_frame.place(x=250, y=20, width=600, height=70)

        cmd_search = ttk.Combobox(search_frame, textvariable=self.var_searchby, values=("Select", "Email", "Name", "Contact"), state='readonly', justify=CENTER, font=("Goudy Old Style", 15))
        cmd_search.place(x=10, y=10, width=180)
        cmd_search.current(0)

        txt_search = Entry(search_frame, textvariable=self.var_searchtxt, font=("Goudy Old Style", 15), bg="lightyellow")
        txt_search.place(x=200, y=10)
        btn_search = Button(search_frame, text="Search", font=("Goudy Old Style", 15), bg="#4caf50", fg="white", cursor="hand2", command=self.search)
        btn_search.place(x=410, y=9, width=150, height=30)

        # Title
        title = Label(self.root, text="Customer Details", font=("Goudy Old Style", 15), bg="#0f4d7d", fg="white")
        title.place(x=50, y=100, width=1000)

        # Content
        lbl_cust_id = Label(self.root, text="Customer ID", font=("Goudy Old Style", 15), bg="white").place(x=30, y=150)
        lbl_gender = Label(self.root, text="Gender", font=("Goudy Old Style", 15), bg="white").place(x=350, y=150)
        lbl_contact = Label(self.root, text="Contact", font=("Goudy Old Style", 15), bg="white").place(x=750, y=150)

        txt_cust_id = Entry(self.root, textvariable=self.var_cust_id, font=("Goudy Old Style", 15), bg="lightyellow",state='disabled')
        txt_cust_id.place(x=150, y=150, width=180)
        
        cmd_gender = ttk.Combobox(self.root, textvariable=self.var_gender, values=("Select", "Male", "Female", "Other"), state='readonly', justify=CENTER, font=("Goudy Old Style", 15))
        cmd_gender.place(x=500, y=150, width=180)
        cmd_gender.current(0)
        
        '''txt_contact = Entry(self.root, textvariable=self.var_contact, font=("Goudy Old Style", 15), bg="lightyellow")
        txt_contact.place(x=850, y=150, width=180)'''
        #lbl_contact = Label(customerFrame, text="Contact No.", font=("times new roman", 15), bg="white").place(x=270, y=35)
        txt_contact = Entry(self.root, textvariable=self.var_contact, font=("times new roman", 15), bg="lightyellow")
        txt_contact.place(x=850, y=150, width=180)
        txt_contact.bind("<KeyRelease>", self.validate_contact)  # Bind validation on key release


        # Row 2
        lbl_name = Label(self.root, text="Name", font=("Goudy Old Style", 15), bg="white").place(x=50, y=190)
        lbl_address = Label(self.root, text="Address", font=("Goudy Old Style", 15), bg="white").place(x=350, y=190)
        lbl_date = Label(self.root, text="Date", font=("Goudy Old Style", 15), bg="white").place(x=750, y=190)

        txt_name = Entry(self.root, textvariable=self.var_name, font=("Goudy Old Style", 15), bg="lightyellow")
        txt_name.place(x=150, y=190, width=180)
        
        self.txt_address = Text(self.root, font=("Goudy Old Style", 15), bg="lightyellow")
        self.txt_address.place(x=500, y=190, width=180, height=30)
        
        txt_date = Entry(self.root, textvariable=self.var_date, font=("Goudy Old Style", 15), bg="lightyellow")
        txt_date.place(x=850, y=190, width=180)

        #======current date================
        self.var_date.set(datetime.now().strftime('%Y-%m-%d'))

        # Buttons
        btn_add = Button(self.root, text="Save", command=self.save, font=("Goudy Old Style", 15), bg="#607d8b", fg="white", cursor="hand2")
        btn_add.place(x=500, y=230, width=110, height=28)
        
        btn_update = Button(self.root, text="Update", command=self.update, font=("Goudy Old Style", 15), bg="#607d8b", fg="white", cursor="hand2")
        btn_update.place(x=620, y=230, width=110, height=28)
        
        btn_delete = Button(self.root, text="Delete", command=self.delete, font=("Goudy Old Style", 15), bg="red", fg="white", cursor="hand2")
        btn_delete.place(x=740, y=230, width=110, height=28)
        
        btn_clear = Button(self.root, text="Clear", command=self.clear, font=("Goudy Old Style", 15), bg="#607d8b", fg="white", cursor="hand2")
        btn_clear.place(x=860, y=230, width=110, height=28)

        # Customer Details Frame
        cust_frame = Frame(self.root, bd=3, relief=RIDGE)
        cust_frame.place(x=0, y=280, relwidth=1, height=220)

        scrolly = Scrollbar(cust_frame, orient=VERTICAL)
        scrollx = Scrollbar(cust_frame, orient=HORIZONTAL)

        self.customerTable = ttk.Treeview(cust_frame, columns=("Cust_id", "Gender", "Contact", "Name", "Address", "Date"), yscrollcommand=scrolly.set, xscrollcommand=scrollx.set)
        scrollx.pack(side=BOTTOM, fill=X)
        scrolly.pack(side=RIGHT, fill=Y) 
        scrollx.config(command=self.customerTable.xview)
        scrolly.config(command=self.customerTable.yview)

        self.customerTable.heading("Cust_id", text="Cust_id")
        self.customerTable.heading("Gender", text="Gender")
        self.customerTable.heading("Contact", text="Contact")
        self.customerTable.heading("Name", text="Name")
        self.customerTable.heading("Address", text="Address")
        self.customerTable.heading("Date", text="Date")

        self.customerTable["show"] = "headings"
        
        self.customerTable.column("Cust_id", width=90)
        self.customerTable.column("Gender", width=100)
        self.customerTable.column("Contact", width=100)
        self.customerTable.column("Name", width=100)
        self.customerTable.column("Address", width=100)
        self.customerTable.column("Date", width=100)
        
        self.customerTable.pack(fill=BOTH, expand=1)
        self.customerTable.bind("<ButtonRelease-1>", self.get_data)

        self.showc()
        
    # Function to add customer
   #''' def save(self):
        #con = sqlite3.connect(database='ims.db')
        #cur = con.cursor()
        #try:
       #     if self.var_cust_id.get() == "":
       #         messagebox.showerror("Error", "Customer ID must be required", parent=self.root)
       #         return  # Stop execution if ID is empty
            
       #     cur.execute("SELECT * FROM customer WHERE cust_id=?", (self.var_cust_id.get(),))
       #     row = cur.fetchone()
       #     if row is not None:
       #         messagebox.showerror("Error", "This customer ID is already assigned, try a different one", parent=self.root)
       #     else:
        #        cur.execute("INSERT INTO customer(Cust_id, Gender, Contact, Name, Address, Date) VALUES(?,?,?,?,?,?)", (
          #          self.var_cust_id.get(),
          #          self.var_gender.get(),
          #          self.var_contact.get(),
          #          self.var_name.get(),
           #         self.txt_address.get('1.0', END),
           #         self.var_date.get()
            #    ))
            #    con.commit()
            #    messagebox.showinfo("Success", "Customer added successfully", parent=self.root)
             #   self.showc()
       # except Exception as ex:
          #  messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)
       # finally:
        #    con.close()


# Function to add customer
    def save(self):
        con = sqlite3.connect(database='ims.db')
        cur = con.cursor()
        try:
        # Automatically generate customer ID
            cur.execute("SELECT MAX(CAST(Cust_id AS INTEGER)) FROM customer")
            max_cust_id = cur.fetchone()[0]
            if max_cust_id is None:
                new_cust_id = 1  # If no customer exists, start from 1
            else:
                new_cust_id = max_cust_id + 1  # Increment the max ID

        # Set the generated customer ID in the entry field
            self.var_cust_id.set(str(new_cust_id))

        # Now proceed to insert the new customer with the generated ID
            cur.execute("INSERT INTO customer(Cust_id, Gender, Contact, Name, Address, Date) VALUES(?,?,?,?,?,?)", (
            new_cust_id,
            self.var_gender.get(),
            self.var_contact.get(),
            self.var_name.get(),
            self.txt_address.get('1.0', END),
            self.var_date.get()
            ))
            con.commit()
            messagebox.showinfo("Success", "Customer added successfully", parent=self.root)
            self.showc()

        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)
        finally:
            con.close()

    def enable_cust_id(self):
        txt_cust_id.config(state='normal')
   # Function to display customer details
    def showc(self):
        con = sqlite3.connect(database='ims.db')
        cur = con.cursor()
        try:
            cur.execute("SELECT * FROM customer")
            rows = cur.fetchall()
            self.customerTable.delete(*self.customerTable.get_children())
            for row in rows:
                self.customerTable.insert('', END, values=row)
        except Exception as ex:
            messagebox.error("Error", f"Error due to: {str(ex)}", parent=self.root)
        finally:
            con.close()

    # Function to get data from table
    def get_data(self, ev):
        f = self.customerTable.focus()
        content = (self.customerTable.item(f))
        row = content['values']
        self.var_cust_id.set(row[0])
        self.var_gender.set(row[1])
        self.var_contact.set(row[2])
        self.var_name.set(row[3])
        self.txt_address.delete('1.0', END)
        self.txt_address.insert(END, row[4])
        self.var_date.set(row[5])

    # Function to update customer details
    def update(self):
        con = sqlite3.connect(database='ims.db')
        cur = con.cursor()
        try:
            if self.var_cust_id.get() == "":
                messagebox.error("Error", "Customer ID must be required", parent=self.root)
                return
            
            cur.execute("SELECT * FROM customer WHERE cust_id=?", (self.var_cust_id.get(),))
            row = cur.fetchone()
            if row is None:
                messagebox.error("Error", "Invalid customer ID", parent=self.root)
            else:
                cur.execute("UPDATE customer SET Gender=?, Contact=?, Name=?, Address=?, Date=? WHERE Cust_id=?", (
                    self.var_gender.get(),
                    self.var_contact.get(),
                    self.var_name.get(),
                    self.txt_address.get('1.0', END),
                    self.var_date.get(),
                    self.var_cust_id.get(),
                ))
                con.commit()
                messagebox.info("Success", "Customer updated successfully", parent=self.root)
                self.showc()
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)
        finally:
            con.close()

    # Function to delete customer
    def delete(self):
        con = sqlite3.connect(database='ims.db')
        cur = con.cursor()
        try:
            if self.var_cust_id.get() == "":
                messagebox.showerror("Error", "Customer ID must be required", parent=self.root)
                return
            
            cur.execute("SELECT * FROM customer WHERE cust_id=?", (self.var_cust_id.get(),))
            row = cur.fetchone()
            if row is None:
                messagebox.showerror("Error", "Invalid customer ID", parent=self.root)
            else:
                op = messagebox.askyesno("Confirm", "Do you really want to delete?", parent=self.root)
                if op == True:
                    cur.execute("DELETE FROM customer WHERE cust_id=?", (self.var_cust_id.get(),))
                    con.commit()
                    messagebox.showinfo("Delete", "Customer deleted successfully", parent=self.root)
                    self.clear()
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)
        finally:
            con.close()

    # Function to clear input fields
    def clear(self):
        self.var_cust_id.set("")
        self.var_gender.set("Select")
        self.var_contact.set("")
        self.var_name.set("")
        self.txt_address.delete('1.0', END)
        self.var_date.set("")
        self.var_searchtxt.set("")
        self.var_searchby.set("Select")
        self.showc()

    # Function to search for customers
    def search(self):
        con = sqlite3.connect(database='ims.db')
        cur = con.cursor()
        try:
            if self.var_searchby.get() == "Select":
                messagebox.showerror("Error", "Select search by option", parent=self.root)
            elif self.var_searchtxt.get() == "":
                messagebox.showerror("Error", "Search input is required", parent=self.root)
            else:
                cur.execute(f"SELECT * FROM customer WHERE {self.var_searchby.get()} LIKE '%{self.var_searchtxt.get()}%'")
                rows = cur.fetchall()
                if rows:
                    self.customerTable.delete(*self.customerTable.get_children())
                    for row in rows:
                        self.customerTable.insert('', END, values=row)
                else:
                    messagebox.showerror("Error", "No record found", parent=self.root)
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)
        finally:
            con.close()
    def validate_contact(self, event):
        contact = self.var_contact.get()

    # Check if the input is numeric and has 10 or fewer digits
        if not contact.isdigit() or len(contact) > 10:
        # If the input is invalid, show a warning and remove the invalid character
            messagebox.showwarning("Invalid Input", "Contact number must be numeric and 10 digits .", parent=self.root)
            self.var_contact.set(contact[:-1])

if __name__ == "__main__":
    root = Tk()
    obj = CustomerClass(root)
    root.mainloop()
