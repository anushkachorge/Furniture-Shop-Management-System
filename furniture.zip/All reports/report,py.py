import sqlite3
import pandas as pd
from fpdf import FPDF

# Connect to SQLite database
conn = sqlite3.connect('ims.db')
cursor = conn.cursor()

# Query data
cursor.execute("SELECT * FROM CUSTOMER")

rows = cursor.fetchall()

# Create DataFrame with column names from the database
df = pd.DataFrame(rows, columns=[desc[0] for desc in cursor.description])

# Save data to CSV and Excel
df.to_csv('report.csv', index=False)
df.to_excel('report.xlsx', index=False)

# Generate PDF Report
class PDF(FPDF):
    def header(self):
        self.set_font("Arial", 'B', 12)
        self.cell(0, 10, 'Customer Report', ln=True, align='C')
        self.ln(5)

    def table_header(self, col_names):
        self.set_font("Arial", 'B', 10)
        for col in col_names:
            self.cell(40, 10, col, 1, 0, 'C')
        self.ln()

    def table_row(self, row_data):
        self.set_font("Arial", size=10)
        for item in row_data:
            self.cell(40, 10, str(item), 1, 0, 'C')
        self.ln()

pdf = PDF()
pdf.add_page()

# Add table header
col_names = df.columns.tolist()
pdf.table_header(col_names)

# Add table rows
for _, row in df.iterrows():
    pdf.table_row(row.values)

pdf.output("report.pdf")

# Close the connection
conn.close()
