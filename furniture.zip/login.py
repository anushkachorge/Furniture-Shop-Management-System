from tkinter import  *
from PIL import Image, ImageTk
from tkinter import messagebox
from dashbord import IMS
import os
import sqlite3
def __init__(self,root):
   self.root=root
root = Tk()
root.configure(bg="light yellow")
root.geometry("1350x700+0+0")

im1=Image.open("images/img2.jpg")
im1=im1.resize((1350,700))
im1=ImageTk.PhotoImage(im1)
lbl_im1=Label(root,image=im1,bd=2,relief=RAISED)
lbl_im1.place(x=0,y=0)





unm=StringVar()
pwd=StringVar()
        
def log():
    username = unm.get()
    password = pwd.get()

    if (username == "Admin" and password == "1234"):
        messagebox.showinfo("", "login success")
        os.system("python dashbord.py")
        
    else:
        messagebox.showerror("Error", "Incorrect username and password")

label1 = Label(root, text="Furniture Shop Management System",bg="#7C3030",fg="white",bd=5,relief=GROOVE,font=("Times new roman",30,"bold"))
label1.place(x=0,y=0,relwidth=1)        

#967969
label1 = Label(root, text="Login Here",bg="#814141",fg="white",bd=5,relief=GROOVE,font=("Times new roman",30,"bold"))
label1.place(x=600,y=65)

label2 = Label(root, text="Username:",font=("Times new roman", 20,"bold"),bg="White", fg="black")
label2.place(x=310 ,y=190)

label3 = Label(root, text="Password:",font=("Times new roman", 20,"bold"),bg="White", fg="black")
label3.place(x=310 ,y=320)

entry1 = Entry(root,font=("Areal", 20),textvariable=unm)
entry1.place(x=600,y = 200)

entry2 = Entry(root,font=("Areal", 20), show="*",textvariable=pwd)
entry2.place(x=600, y= 320)

button = Button(root, text="Login",bg="yellow",font=("Times new roman",20,"bold"), bd=5, command=log)
button.place(x=700, y=450)
#command=self.IMS
#def dashboard(self):
#        self.new_win=Toplevel(self.root)
#        self.new_obj=IMS(self.new_win)

root.mainloop()



