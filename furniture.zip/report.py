from tkinter import*
from PIL import Image ,ImageTk #pip install pillow
from custreport import custreportClass
from stockreport import stockreportClass
from supreport import supreportClass
from CBreport import cbreportClass
from sbreport import sbreportClass

class reportClass:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1100x500+220+130")

        self.root.title("Furniture Shop Management System ")
        self.root.config(bg="white")


        #===title===
        #self.icon_title=PhotoImage(file="imges/logo1.png")
        title=Label(self.root,text="Furniture Shop Management System",compound=LEFT,font=("times new roman",40,"bold"),bg="#010c48",fg="white",anchor="w",padx=20).place(x=0,y=0,relwidth=1,height=70) 
        #,image=self.icon_title
        #==button logout==

        #==clock===
        #====Left Menu==
        #self.left_MenuLogo=Image.open("imges/menulogo.jpg")
        #self.left_MenuLogo= self.left_MenuLogo.resize((50,50))
        #self.left_MenuLogo=ImageTk.PhotoImage( self.left_MenuLogo)

        LeftMenu=Frame(self.root,bd=2,relief=RIDGE,bg="white")
        LeftMenu.place(x=0,y=102,width=250,height=320)

        #lbl_menulogo=Label(LeftMenu,image=self.left_MenuLogo)
        #lbl_menulogo.pack(side=TOP,fill=X)

        lbl_menu=Label(LeftMenu,text="Report",font=("times new roman",20),bg="#009688").pack(side=TOP,fill=X)
        #self.icon_side

        btn_Patient=Button(LeftMenu,text="Customer",command=self.customer,compound=LEFT,padx=5,anchor="w",font=("times new roman",20,"bold"),bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)
        btn_supplier=Button(LeftMenu,text="Stock",command=self.stock,compound=LEFT,padx=5,anchor="w",font=("times new roman",20,"bold"),bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)
        btn_suppbill=Button(LeftMenu,text="Supplier ",command=self.supplier,compound=LEFT,padx=5,anchor="w",font=("times new roman",20,"bold"),bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)
        btn_supporder=Button(LeftMenu,text="Customer Bill",command=self.customer_Bill,compound=LEFT,padx=5,anchor="w",font=("times new roman",20,"bold"),bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)
        btn_stock=Button(LeftMenu,text="Supplier Bill",command=self.supplier_Bill,compound=LEFT,padx=5,anchor="w",font=("times new roman",20,"bold"),bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)

#,command=self.Patient,image=self.icon_side
#,command=self.supplier,image=self.icon_side
    def customer(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=custreportClass(self.new_win)

    def stock(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=stockreportClass(self.new_win)

    def supplier(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=supreportClass(self.new_win)

    def customer_Bill(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=cbreportClass(self.new_win)

    def supplier_Bill(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=sbreportClass(self.new_win)
if __name__=="__main__":
    root=Tk()
    obj=reportClass(root)
    root.mainloop()

